package edu.illinois.cs242.models;

import edu.illinois.cs242.pieces.Bishop;
import edu.illinois.cs242.pieces.ChessPiece;
import edu.illinois.cs242.pieces.King;
import edu.illinois.cs242.pieces.Knight;
import edu.illinois.cs242.pieces.Pawn;
import edu.illinois.cs242.pieces.Queen;
import edu.illinois.cs242.pieces.Rook;

/**
 * The Class SubmittedMove. Represents a move submitted by a player, keeping track of
 * the piece moved, the piece taken (if one), and their board position
 */
public class SubmittedMove {
	
	/** The piece taken. */
	ChessPiece pieceMoved, pieceTaken;
	
	/**
	 * Gets the piece moved.
	 *
	 * @return the piece moved
	 */
	public ChessPiece getPieceMoved() {
		return pieceMoved;
	}

	/** The dest y. */
	int originX, originY, destX, destY;
	
	/**
	 * Gets the piece taken.
	 *
	 * @return the piece taken
	 */
	public ChessPiece getPieceTaken() {
		return pieceTaken;
	}

	/**
	 * Gets the origin x.
	 *
	 * @return the origin x
	 */
	public int getOriginX() {
		return originX;
	}

	/**
	 * Gets the origin y.
	 *
	 * @return the origin y
	 */
	public int getOriginY() {
		return originY;
	}

	/**
	 * Gets the dest x.
	 *
	 * @return the dest x
	 */
	public int getDestX() {
		return destX;
	}

	/**
	 * Gets the dest y.
	 *
	 * @return the dest y
	 */
	public int getDestY() {
		return destY;
	}

	/**
	 * Instantiates a new submitted move.
	 *
	 * @param fromX the from x
	 * @param fromY the from y
	 * @param toX the to x
	 * @param toY the to y
	 * @param pieceMoved the piece moved
	 * @param pieceTaken the piece taken
	 */
	public SubmittedMove(int fromX, int fromY, int toX, int toY, ChessPiece pieceMoved, ChessPiece pieceTaken){
		this.originX = fromX;
		this.originY = fromY;
		this.destX = toX;
		this.destY = toY;
		if(pieceTaken instanceof Pawn) this.pieceTaken = new Pawn( (Pawn) pieceTaken);
		if(pieceTaken instanceof Rook) this.pieceTaken = new Rook( (Rook) pieceTaken);
		if(pieceTaken instanceof Knight) this.pieceTaken = new Knight( (Knight) pieceTaken);
		if(pieceTaken instanceof Bishop) this.pieceTaken = new Bishop( (Bishop) pieceTaken);
		if(pieceTaken instanceof Queen) this.pieceTaken = new Queen( (Queen) pieceTaken);
		if(pieceTaken instanceof King) this.pieceTaken = new King( (King) pieceTaken);
		
		if(pieceMoved instanceof Pawn) this.pieceMoved = new Pawn( (Pawn) pieceMoved);
		if(pieceMoved instanceof Rook) this.pieceMoved = new Rook( (Rook) pieceMoved);
		if(pieceMoved instanceof Knight) this.pieceMoved = new Knight( (Knight) pieceMoved);
		if(pieceMoved instanceof Bishop) this.pieceMoved = new Bishop( (Bishop) pieceMoved);
		if(pieceMoved instanceof Queen) this.pieceMoved = new Queen( (Queen) pieceMoved);
		if(pieceMoved instanceof King) this.pieceMoved = new King( (King) pieceMoved);
	}
}
