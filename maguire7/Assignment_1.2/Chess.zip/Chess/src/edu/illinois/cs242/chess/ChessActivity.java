package edu.illinois.cs242.chess;



import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

// TODO: Auto-generated Javadoc
/**
 * The Class Chess.
 */
public class ChessActivity extends JFrame{
	
	/** The white agrees to restart. */
	public boolean whiteAgreesToRestart;
	
	/** The black agrees to restart. */
	public boolean blackAgreesToRestart;
	
	/** The white has forfeited. */
	public boolean whiteHasForfeited;
	
	/** The black has forfeited. */
	public boolean blackHasForfeited;
	
	/** The white win count. */
	public int whiteWinCount;
	
	/** The black win count. */
	public int blackWinCount;
	
	/** The black win count label. */
	private Label blackWinCountLabel;
	
	/** The white win count label. */
	private Label whiteWinCountLabel;
	
	/** The game option controller. */
	JPanel gameOptionController;
	
	/** The chess board controller. */
	ChessBoardController chessBoardController;
	
	/**
	 * Instantiates a new chess.
	 */
	public ChessActivity(){
		initUI();
	}
	
	/**
	 * Inits the ui.
	 */
	private void initUI() {
		chessBoardController = new ChessBoardController();
		
		gameOptionController = new JPanel();
		gameOptionController.setLayout(new GridLayout(7,1));
		
		JButton whiteAgreesToRestartButton = whiteAgreesToRestartButton();
		JButton blackAgreesToRestartButton = blackAgreesToRestartButton();
		JButton whiteForfeitsButton = whiteForfeitButton();
		JButton blackForfeitsButton = blackForfeitsButton();
		JButton undoButton = undoButton();
		
		blackWinCountLabel = new Label("Black has won " + blackWinCount + " games.");
		whiteWinCountLabel = new Label("White has won " + whiteWinCount + " games.");
		
		gameOptionController.add(whiteForfeitsButton);
		gameOptionController.add(whiteAgreesToRestartButton);
		gameOptionController.add(undoButton);
		gameOptionController.add(blackAgreesToRestartButton);
		gameOptionController.add(blackForfeitsButton);
		gameOptionController.add(whiteWinCountLabel);
		gameOptionController.add(blackWinCountLabel);
		
		
		setTitle("Chess");
		setSize(1200,600);
		setLayout(new GridLayout(1,2));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		add(chessBoardController);
		add(gameOptionController);
	}

	/**
	 * Undo button.
	 *
	 * @return the j button
	 */
	private JButton undoButton() {
		JButton undoButton = new JButton();
		
		undoButton.setText("Undo");		
		
		undoButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				chessBoardController.undoMove();
			}
		});
		return undoButton;
	}

	/**
	 * White agrees to restart button.
	 *
	 * @return the j button
	 */
	private JButton whiteAgreesToRestartButton() {
		JButton whiteAgreesToRestartButton = new JButton();
		whiteAgreesToRestartButton.setText("White agrees to restart");

		whiteAgreesToRestartButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				whiteAgreesToRestart = true;
				if(blackAgreesToRestart && whiteAgreesToRestart){
					chessBoardController.restartGame();
					whiteAgreesToRestart = blackAgreesToRestart = false;
				}
			}
		});
		return whiteAgreesToRestartButton;
	}

	/**
	 * Black agrees to restart button.
	 *
	 * @return the j button
	 */
	private JButton blackAgreesToRestartButton() {
		JButton blackAgreesToRestartButton = new JButton();
		blackAgreesToRestartButton.setText("Black agrees to restart");

		blackAgreesToRestartButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				blackAgreesToRestart = true;
				if(blackAgreesToRestart && whiteAgreesToRestart){
					chessBoardController.restartGame();
					whiteAgreesToRestart = blackAgreesToRestart = false;
				}
			}
		});
		return blackAgreesToRestartButton;
	}

	/**
	 * Black forfeits button.
	 *
	 * @return the j button
	 */
	private JButton blackForfeitsButton() {
		JButton blackForfeitsButton = new JButton();
		
		blackForfeitsButton.setText("Black forfeits");
		
		blackForfeitsButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				blackHasForfeited = true;
			}
		});
		return blackForfeitsButton;
	}

	/**
	 * White forfeit button.
	 *
	 * @return the j button
	 */
	private JButton whiteForfeitButton() {
		JButton whiteForfeitsButton = new JButton();

		whiteForfeitsButton.setText("White forfeits");

		whiteForfeitsButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				whiteHasForfeited = true;
			}
		});
		return whiteForfeitsButton;
	}
	
	/**
	 * Checks for winner.
	 *
	 * @return the int
	 */
	private int hasWinner() {
		return this.chessBoardController.hasWinner();
	}

	/**
	 * Update win count labels.
	 */
	private void updateWinCountLabels() {
		blackWinCountLabel.setText("Black has won " + blackWinCount + " games.");
		whiteWinCountLabel.setText("White has won " + whiteWinCount + " games.");
	}
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args){
		ChessActivity chessActivity = new ChessActivity();
		chessActivity.setVisible(true);
		int winner = 0;
		while(true){
			winner = chessActivity.hasWinner();
			if(winner == Board.BLACK || chessActivity.whiteHasForfeited){
				chessActivity.whiteHasForfeited = false;
				chessActivity.blackWinCount += 1;
				chessActivity.updateWinCountLabels();
				while(chessActivity.hasWinner() == Board.BLACK || chessActivity.whiteHasForfeited);
			}
			if(winner == Board.WHITE || chessActivity.blackHasForfeited){
				chessActivity.blackHasForfeited = false;
				chessActivity.whiteWinCount += 1;
				chessActivity.updateWinCountLabels();
				while(chessActivity.hasWinner() == Board.WHITE || chessActivity.blackHasForfeited);
			}
		}
	}

	

	
}
