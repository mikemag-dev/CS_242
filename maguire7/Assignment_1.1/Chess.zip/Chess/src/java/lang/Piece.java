package java.lang;

public enum Piece {
	PAWN, ROOK, KNIGHT, BISHIP, QUEEN, KING
}
